import os
import re
import json

from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


# ============================================================
# FYZIE PROFESSIONAL BOOK BUILDER
# ============================================================

PLAN_FILE = "data/book_plan.json"
CHAPTER_DIR = "data/generated_chapters"
OUTPUT_DIR = "output"

AUTHOR = "Sachintha Imesh"
BRAND = "(FYZIE)"


# ============================================================
# LOAD BOOK PLAN
# ============================================================

def load_plan():

    if not os.path.exists(PLAN_FILE):
        raise FileNotFoundError(
            f"Book plan not found: {PLAN_FILE}"
        )

    with open(
        PLAN_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


# ============================================================
# PAGE NUMBER
# ============================================================

def add_page_number(paragraph):

    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = paragraph.add_run()

    field_begin = OxmlElement("w:fldChar")
    field_begin.set(
        qn("w:fldCharType"),
        "begin"
    )

    instruction = OxmlElement("w:instrText")
    instruction.set(
        qn("xml:space"),
        "preserve"
    )

    instruction.text = " PAGE "

    field_end = OxmlElement("w:fldChar")
    field_end.set(
        qn("w:fldCharType"),
        "end"
    )

    run._r.append(field_begin)
    run._r.append(instruction)
    run._r.append(field_end)


# ============================================================
# TWO COLUMN LAYOUT
# ============================================================

def set_double_columns(section):

    sectPr = section._sectPr

    cols = sectPr.xpath("./w:cols")

    if cols:

        cols = cols[0]

    else:

        cols = OxmlElement("w:cols")

        sectPr.append(cols)

    cols.set(
        qn("w:num"),
        "2"
    )

    cols.set(
        qn("w:space"),
        "720"
    )


# ============================================================
# HEADER
# ============================================================

def setup_header(section, book_title):

    header = section.header

    paragraph = header.paragraphs[0]

    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = paragraph.add_run(
        f"{book_title}  •  {BRAND}"
    )

    run.font.name = "Arial"
    run.font.size = Pt(8)
    run.bold = True


# ============================================================
# FOOTER
# ============================================================

def setup_footer(section):

    footer = section.footer

    paragraph = footer.paragraphs[0]

    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = paragraph.add_run(
        f"{AUTHOR}  •  {BRAND}  •  "
    )

    run.font.name = "Arial"
    run.font.size = Pt(8)

    add_page_number(paragraph)


# ============================================================
# DOCUMENT SETUP
# ============================================================

def setup_document(doc, book_title):

    section = doc.sections[0]

    # A4
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)

    # Margins
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)

    setup_header(
        section,
        book_title
    )

    setup_footer(section)

    # Main body
    set_double_columns(section)


# ============================================================
# STYLES
# ============================================================

def setup_styles(doc):

    styles = doc.styles

    # --------------------------------------------------------
    # NORMAL
    # --------------------------------------------------------

    normal = styles["Normal"]

    normal.font.name = "Arial"
    normal.font.size = Pt(10)

    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.08

    # --------------------------------------------------------
    # TITLE
    # --------------------------------------------------------

    title = styles["Title"]

    title.font.name = "Arial"
    title.font.size = Pt(28)
    title.font.bold = True

    title.paragraph_format.space_after = Pt(15)

    # --------------------------------------------------------
    # HEADING 1
    # --------------------------------------------------------

    heading1 = styles["Heading 1"]

    heading1.font.name = "Arial"
    heading1.font.size = Pt(18)
    heading1.font.bold = True

    heading1.paragraph_format.space_before = Pt(14)
    heading1.paragraph_format.space_after = Pt(7)

    heading1.paragraph_format.keep_with_next = True

    # --------------------------------------------------------
    # HEADING 2
    # --------------------------------------------------------

    heading2 = styles["Heading 2"]

    heading2.font.name = "Arial"
    heading2.font.size = Pt(13)
    heading2.font.bold = True

    heading2.paragraph_format.space_before = Pt(9)
    heading2.paragraph_format.space_after = Pt(5)

    heading2.paragraph_format.keep_with_next = True

    # --------------------------------------------------------
    # HEADING 3
    # --------------------------------------------------------

    heading3 = styles["Heading 3"]

    heading3.font.name = "Arial"
    heading3.font.size = Pt(11)
    heading3.font.bold = True

    heading3.paragraph_format.space_before = Pt(7)
    heading3.paragraph_format.space_after = Pt(4)

    heading3.paragraph_format.keep_with_next = True


# ============================================================
# TITLE PAGE
# ============================================================

def add_title_page(
    doc,
    book_title
):

    # Add vertical spacing
    for _ in range(5):

        paragraph = doc.add_paragraph()

        paragraph.paragraph_format.space_after = Pt(10)

    # --------------------------------------------------------
    # BRAND
    # --------------------------------------------------------

    brand = doc.add_paragraph()

    brand.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = brand.add_run(
        BRAND
    )

    run.font.name = "Arial"
    run.font.size = Pt(18)
    run.bold = True

    # --------------------------------------------------------
    # BOOK TITLE
    # --------------------------------------------------------

    title = doc.add_paragraph()

    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = title.add_run(
        book_title
    )

    run.font.name = "Arial"
    run.font.size = Pt(30)
    run.bold = True

    title.paragraph_format.space_after = Pt(25)

    # --------------------------------------------------------
    # SUBTITLE
    # --------------------------------------------------------

    subtitle = doc.add_paragraph()

    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = subtitle.add_run(
        "Complete Professional Frontend Development Course"
    )

    run.font.name = "Arial"
    run.font.size = Pt(14)

    subtitle.paragraph_format.space_after = Pt(30)

    # --------------------------------------------------------
    # AUTHOR
    # --------------------------------------------------------

    author = doc.add_paragraph()

    author.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = author.add_run(
        "Author"
    )

    run.font.name = "Arial"
    run.font.size = Pt(10)

    author.paragraph_format.space_after = Pt(4)

    author_name = doc.add_paragraph()

    author_name.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = author_name.add_run(
        AUTHOR
    )

    run.font.name = "Arial"
    run.font.size = Pt(16)
    run.bold = True

    doc.add_page_break()


# ============================================================
# VOLUME TITLE PAGE
# ============================================================

def add_volume_page(
    doc,
    volume
):

    paragraph = doc.add_paragraph()

    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    paragraph.paragraph_format.space_before = Pt(120)

    run = paragraph.add_run(
        f"VOLUME {volume.get('volume_number')}"
    )

    run.font.name = "Arial"
    run.font.size = Pt(24)
    run.bold = True

    paragraph2 = doc.add_paragraph()

    paragraph2.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = paragraph2.add_run(
        volume.get(
            "volume_title",
            ""
        )
    )

    run.font.name = "Arial"
    run.font.size = Pt(18)
    run.bold = True

    purpose = volume.get(
        "purpose",
        ""
    )

    if purpose:

        paragraph3 = doc.add_paragraph()

        paragraph3.alignment = WD_ALIGN_PARAGRAPH.CENTER

        paragraph3.paragraph_format.space_before = Pt(20)

        run = paragraph3.add_run(
            purpose
        )

        run.font.name = "Arial"
        run.font.size = Pt(10)

    doc.add_page_break()


# ============================================================
# TABLE OF CONTENTS
# ============================================================

def add_table_of_contents(
    doc,
    plan
):

    heading = doc.add_paragraph()

    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER

    run = heading.add_run(
        "Table of Contents"
    )

    run.font.name = "Arial"
    run.font.size = Pt(22)
    run.bold = True

    doc.add_paragraph()

    for volume in plan.get(
        "volumes",
        []
    ):

        volume_number = volume.get(
            "volume_number"
        )

        volume_title = volume.get(
            "volume_title",
            ""
        )

        paragraph = doc.add_paragraph()

        run = paragraph.add_run(
            f"Volume {volume_number}: "
            f"{volume_title}"
        )

        run.font.name = "Arial"
        run.font.size = Pt(12)
        run.bold = True

        for chapter in volume.get(
            "chapters",
            []
        ):

            chapter_number = chapter.get(
                "chapter_number"
            )

            chapter_title = chapter.get(
                "chapter_title",
                ""
            )

            paragraph = doc.add_paragraph()

            paragraph.paragraph_format.left_indent = Inches(
                0.25
            )

            run = paragraph.add_run(
                f"Chapter {chapter_number}: "
                f"{chapter_title}"
            )

            run.font.name = "Arial"
            run.font.size = Pt(9)

    doc.add_page_break()


# ============================================================
# HEADING DETECTION
# ============================================================

def is_chapter_heading(line):

    line = line.strip()

    patterns = [

        r"^Chapter\s+\d+",
        r"^CHAPTER\s+\d+",
        r"^Chapter\s+\d+\s*:",
        r"^CHAPTER\s+\d+\s*:",

    ]

    for pattern in patterns:

        if re.match(
            pattern,
            line,
            re.IGNORECASE
        ):

            return True

    return False


def is_heading(line):

    line = line.strip()

    if not line:
        return False

    # Markdown heading
    if line.startswith("#"):

        return True

    # Numbered headings
    if re.match(
        r"^\d+\.\d+\.\d+\s+",
        line
    ):

        return True

    if re.match(
        r"^\d+\.\d+\s+",
        line
    ):

        return True

    if re.match(
        r"^\d+\.\s+",
        line
    ):

        return True

    return False


# ============================================================
# CLEAN HEADING
# ============================================================

def clean_heading(line):

    line = line.strip()

    # Remove Markdown hashes
    line = re.sub(
        r"^#+\s*",
        "",
        line
    )

    return line.strip()


# ============================================================
# CODE DETECTION
# ============================================================

def is_code_line(line):

    stripped = line.strip()

    if stripped.startswith("```"):
        return True

    return False


# ============================================================
# ADD CHAPTER
# ============================================================

def add_chapter(
    doc,
    chapter_number,
    content
):

    lines = content.splitlines()

    in_code_block = False

    code_buffer = []

    for raw_line in lines:

        line = raw_line.rstrip()

        # ----------------------------------------------------
        # CODE BLOCK START / END
        # ----------------------------------------------------

        if line.strip().startswith("```"):

            if not in_code_block:

                in_code_block = True
                code_buffer = []

            else:

                in_code_block = False

                if code_buffer:

                    paragraph = doc.add_paragraph()

                    paragraph.paragraph_format.space_before = Pt(4)
                    paragraph.paragraph_format.space_after = Pt(7)

                    for code_line in code_buffer:

                        run = paragraph.add_run(
                            code_line + "\n"
                        )

                        run.font.name = "Consolas"
                        run.font.size = Pt(8.5)

                    code_buffer = []

            continue

        if in_code_block:

            code_buffer.append(
                line
            )

            continue

        # ----------------------------------------------------
        # EMPTY LINE
        # ----------------------------------------------------

        if not line.strip():

            continue

        # ----------------------------------------------------
        # HORIZONTAL RULE
        # ----------------------------------------------------

        if line.strip() == "---":

            paragraph = doc.add_paragraph()

            paragraph.paragraph_format.space_after = Pt(6)

            run = paragraph.add_run(
                "────────────────────────"
            )

            run.font.name = "Arial"
            run.font.size = Pt(7)

            continue

        # ----------------------------------------------------
        # CHAPTER TITLE
        # ----------------------------------------------------

        if is_chapter_heading(line):

            paragraph = doc.add_paragraph(
                style="Heading 1"
            )

            run = paragraph.add_run(
                clean_heading(line)
            )

            run.font.name = "Arial"
            run.font.size = Pt(18)
            run.bold = True

            continue

        # ----------------------------------------------------
        # NORMAL HEADING
        # ----------------------------------------------------

        if is_heading(line):

            paragraph = doc.add_paragraph(
                style="Heading 2"
            )

            run = paragraph.add_run(
                clean_heading(line)
            )

            run.font.name = "Arial"
            run.font.size = Pt(13)
            run.bold = True

            continue

        # ----------------------------------------------------
        # BULLET
        # ----------------------------------------------------

        if re.match(
            r"^\s*[-*]\s+",
            line
        ):

            text = re.sub(
                r"^\s*[-*]\s+",
                "",
                line
            )

            paragraph = doc.add_paragraph(
                style="List Bullet"
            )

            run = paragraph.add_run(
                text
            )

            run.font.name = "Arial"
            run.font.size = Pt(10)

            continue

        # ----------------------------------------------------
        # NUMBERED LIST
        # ----------------------------------------------------

        if re.match(
            r"^\s*\d+\.\s+",
            line
        ):

            paragraph = doc.add_paragraph(
                style="List Number"
            )

            text = re.sub(
                r"^\s*\d+\.\s+",
                "",
                line
            )

            run = paragraph.add_run(
                text
            )

            run.font.name = "Arial"
            run.font.size = Pt(10)

            continue

        # ----------------------------------------------------
        # NORMAL PARAGRAPH
        # ----------------------------------------------------

        paragraph = doc.add_paragraph()

        paragraph.paragraph_format.space_after = Pt(5)
        paragraph.paragraph_format.line_spacing = 1.08

        run = paragraph.add_run(
            line.strip()
        )

        run.font.name = "Arial"
        run.font.size = Pt(10)


# ============================================================
# FIND CHAPTER FILE
# ============================================================

def get_chapter_file(
    chapter_number
):

    filename = (
        f"chapter_{chapter_number:03d}.txt"
    )

    path = os.path.join(
        CHAPTER_DIR,
        filename
    )

    if os.path.exists(path):

        return path

    return None


# ============================================================
# BUILD COMPLETE BOOK
# ============================================================

def build_book():

    os.makedirs(
        OUTPUT_DIR,
        exist_ok=True
    )

    plan = load_plan()

    book_title = plan.get(
        "book_title",
        "Untitled Book"
    )

    # --------------------------------------------------------
    # CREATE DOCUMENT
    # --------------------------------------------------------

    doc = Document()

    setup_document(
        doc,
        book_title
    )

    setup_styles(
        doc
    )

    # --------------------------------------------------------
    # TITLE PAGE
    # --------------------------------------------------------

    add_title_page(
        doc,
        book_title
    )

    # --------------------------------------------------------
    # TABLE OF CONTENTS
    # --------------------------------------------------------

    add_table_of_contents(
        doc,
        plan
    )

    # --------------------------------------------------------
    # VOLUMES
    # --------------------------------------------------------

    total_chapters = sum(
        len(
            volume.get(
                "chapters",
                []
            )
        )
        for volume in plan.get(
            "volumes",
            []
        )
    )

    added_chapters = 0

    print("=" * 60)
    print("FYZIE PROFESSIONAL BOOK BUILDER")
    print("=" * 60)

    print(
        f"Book     : {book_title}"
    )

    print(
        f"Author   : {AUTHOR}"
    )

    print(
        f"Brand    : {BRAND}"
    )

    print(
        f"Volumes  : "
        f"{len(plan.get('volumes', []))}"
    )

    print(
        f"Chapters : {total_chapters}"
    )

    print("=" * 60)

    for volume_index, volume in enumerate(
        plan.get("volumes", [])
    ):

        # ----------------------------------------------------
        # VOLUME PAGE
        # ----------------------------------------------------

        add_volume_page(
            doc,
            volume
        )

        # ----------------------------------------------------
        # CHAPTERS
        # ----------------------------------------------------

        for chapter in volume.get(
            "chapters",
            []
        ):

            chapter_number = chapter.get(
                "chapter_number"
            )

            chapter_title = chapter.get(
                "chapter_title",
                ""
            )

            path = get_chapter_file(
                chapter_number
            )

            print()

            if path is None:

                print(
                    f"[MISSING] Chapter "
                    f"{chapter_number}/{total_chapters}"
                )

                print(
                    f"          {chapter_title}"
                )

                continue

            print(
                f"[ADDING] Chapter "
                f"{chapter_number}/{total_chapters}"
            )

            print(
                f"        {chapter_title}"
            )

            # ------------------------------------------------
            # READ ORIGINAL CONTENT
            # ------------------------------------------------

            with open(
                path,
                "r",
                encoding="utf-8"
            ) as file:

                content = file.read()

            # ------------------------------------------------
            # ADD ORIGINAL CONTENT
            # ------------------------------------------------

            add_chapter(
                doc,
                chapter_number,
                content
            )

            added_chapters += 1

            # ------------------------------------------------
            # CHAPTER BREAK
            # ------------------------------------------------

            if chapter_number != total_chapters:

                doc.add_page_break()

    # --------------------------------------------------------
    # SAVE
    # --------------------------------------------------------

    output_file = os.path.join(
        OUTPUT_DIR,
        "FYZIE_Modern_Frontend_Development.docx"
    )

    doc.save(
        output_file
    )

    print()
    print("=" * 60)
    print("BOOK CREATED SUCCESSFULLY!")
    print("=" * 60)

    print(
        f"Chapters added : "
        f"{added_chapters}/{total_chapters}"
    )

    print(
        f"Output         : "
        f"{output_file}"
    )

    print("=" * 60)


# ============================================================
# PROGRAM START
# ============================================================

if __name__ == "__main__":

    try:

        build_book()

    except KeyboardInterrupt:

        print()
        print(
            "Book building stopped."
        )

    except Exception as error:

        print()
        print(
            "ERROR:"
        )

        print(
            error
        )