import os
import re
import json
from collections import Counter

# ============================================================
# FYZIE BOOK CHECKER
# Checks generated chapters without using any AI/API
# ============================================================

PLAN_FILE = "data/book_plan.json"
CHAPTER_DIR = "data/generated_chapters"

MIN_CHAPTER_LENGTH = 1000

# Characters that commonly indicate UTF-8 -> Windows-1252
# mojibake / encoding corruption.
CORRUPTED_PATTERNS = [
    "â€¢",
    "â€“",
    "â€”",
    "â€˜",
    "â€™",
    "â€œ",
    "â€",
    "â€¦",
    "â†’",
    "â†",
    "âœ“",
    "âœ—",
    "â”€",
    "â”‚",
    "â”Œ",
    "â”",
    "â””",
    "â”˜",
    "Ã©",
    "Ã¨",
    "Ã",
    "Â",
]


# ============================================================
# LOAD PLAN
# ============================================================

def load_plan():

    if not os.path.exists(PLAN_FILE):
        raise FileNotFoundError(
            f"Book plan not found: {PLAN_FILE}"
        )

    with open(
        PLAN_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


# ============================================================
# GET EXPECTED CHAPTERS
# ============================================================

def get_expected_chapters(plan):

    expected = []

    for volume in plan.get("volumes", []):

        for chapter in volume.get("chapters", []):

            number = chapter.get("chapter_number")
            title = chapter.get("chapter_title", "")

            if number is not None:

                expected.append(
                    {
                        "number": int(number),
                        "title": title,
                        "volume": volume.get(
                            "volume_number"
                        ),
                    }
                )

    expected.sort(
        key=lambda x: x["number"]
    )

    return expected


# ============================================================
# CHAPTER PATH
# ============================================================

def chapter_path(number):

    return os.path.join(
        CHAPTER_DIR,
        f"chapter_{number:03d}.txt"
    )


# ============================================================
# CHECK ONE CHAPTER
# ============================================================

def check_chapter(number):

    path = chapter_path(number)

    result = {
        "number": number,
        "exists": False,
        "size_bytes": 0,
        "characters": 0,
        "lines": 0,
        "empty": False,
        "too_short": False,
        "corruption": [],
        "read_error": None,
    }

    if not os.path.exists(path):

        return result

    result["exists"] = True

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as file:

            content = file.read()

        result["size_bytes"] = os.path.getsize(path)
        result["characters"] = len(content)
        result["lines"] = len(content.splitlines())

        result["empty"] = not content.strip()

        result["too_short"] = (
            len(content.strip())
            < MIN_CHAPTER_LENGTH
        )

        found = []

        for pattern in CORRUPTED_PATTERNS:

            if pattern in content:

                found.append(pattern)

        result["corruption"] = found

    except Exception as error:

        result["read_error"] = str(error)

    return result


# ============================================================
# PRINT HEADER
# ============================================================

def print_header():

    print()
    print("=" * 75)
    print("FYZIE BOOK QUALITY CHECKER")
    print("=" * 75)
    print("AI/API calls: NONE")
    print("Mode: LOCAL FILE CHECK ONLY")
    print("=" * 75)


# ============================================================
# MAIN CHECK
# ============================================================

def run_checker():

    print_header()

    plan = load_plan()

    expected = get_expected_chapters(plan)

    if not expected:

        raise RuntimeError(
            "No chapters found in book_plan.json"
        )

    expected_numbers = [
        item["number"]
        for item in expected
    ]

    print()
    print(
        f"Expected chapters : "
        f"{len(expected_numbers)}"
    )

    print(
        f"Expected range    : "
        f"{min(expected_numbers)} - "
        f"{max(expected_numbers)}"
    )

    print()
    print("-" * 75)

    # --------------------------------------------------------
    # CHECK ALL EXPECTED CHAPTERS
    # --------------------------------------------------------

    results = []

    for item in expected:

        result = check_chapter(
            item["number"]
        )

        result["title"] = item["title"]
        result["volume"] = item["volume"]

        results.append(result)

    # --------------------------------------------------------
    # SUMMARY
    # --------------------------------------------------------

    existing = [
        r for r in results
        if r["exists"]
    ]

    missing = [
        r for r in results
        if not r["exists"]
    ]

    empty = [
        r for r in results
        if r["exists"] and r["empty"]
    ]

    too_short = [
        r for r in results
        if r["exists"] and r["too_short"]
    ]

    corrupted = [
        r for r in results
        if r["exists"] and r["corruption"]
    ]

    read_errors = [
        r for r in results
        if r["read_error"]
    ]

    # --------------------------------------------------------
    # DUPLICATE / UNEXPECTED FILES
    # --------------------------------------------------------

    actual_files = []

    if os.path.exists(CHAPTER_DIR):

        for filename in os.listdir(CHAPTER_DIR):

            match = re.fullmatch(
                r"chapter_(\d+)\.txt",
                filename,
                re.IGNORECASE
            )

            if match:

                actual_files.append(
                    int(match.group(1))
                )

    actual_counter = Counter(
        actual_files
    )

    unexpected = sorted(
        set(actual_files)
        - set(expected_numbers)
    )

    duplicates = [
        number
        for number, count
        in actual_counter.items()
        if count > 1
    ]

    # --------------------------------------------------------
    # TOTAL CHARACTERS
    # --------------------------------------------------------

    total_characters = sum(
        r["characters"]
        for r in existing
    )

    total_bytes = sum(
        r["size_bytes"]
        for r in existing
    )

    # --------------------------------------------------------
    # PRINT STATUS
    # --------------------------------------------------------

    print()
    print("=" * 75)
    print("CHAPTER STATUS")
    print("=" * 75)

    for result in results:

        number = result["number"]

        if not result["exists"]:

            status = "MISSING"

        elif result["read_error"]:

            status = "READ ERROR"

        elif result["empty"]:

            status = "EMPTY"

        elif result["too_short"]:

            status = "TOO SHORT"

        elif result["corruption"]:

            status = "UNICODE ISSUE"

        else:

            status = "OK"

        print(
            f"Chapter {number:03d} : "
            f"{status:14} | "
            f"{result['characters']:>9,} chars | "
            f"{result['title']}"
        )

    # --------------------------------------------------------
    # SUMMARY REPORT
    # --------------------------------------------------------

    print()
    print("=" * 75)
    print("SUMMARY")
    print("=" * 75)

    print(
        f"Expected chapters : "
        f"{len(expected_numbers)}"
    )

    print(
        f"Existing chapters : "
        f"{len(existing)}"
    )

    print(
        f"Missing chapters  : "
        f"{len(missing)}"
    )

    print(
        f"Empty chapters    : "
        f"{len(empty)}"
    )

    print(
        f"Too-short chapters: "
        f"{len(too_short)}"
    )

    print(
        f"Unicode issues    : "
        f"{len(corrupted)}"
    )

    print(
        f"Read errors       : "
        f"{len(read_errors)}"
    )

    print(
        f"Unexpected files  : "
        f"{len(unexpected)}"
    )

    print(
        f"Duplicate numbers : "
        f"{len(duplicates)}"
    )

    print(
        f"Total characters  : "
        f"{total_characters:,}"
    )

    print(
        f"Total file size   : "
        f"{total_bytes / 1024 / 1024:.2f} MB"
    )

    # --------------------------------------------------------
    # MISSING
    # --------------------------------------------------------

    if missing:

        print()
        print("=" * 75)
        print("MISSING CHAPTERS")
        print("=" * 75)

        for result in missing:

            print(
                f"Chapter {result['number']}: "
                f"{result['title']}"
            )

    # --------------------------------------------------------
    # SHORT / EMPTY
    # --------------------------------------------------------

    if empty or too_short:

        print()
        print("=" * 75)
        print("CONTENT PROBLEMS")
        print("=" * 75)

        for result in empty:

            print(
                f"Chapter {result['number']}: EMPTY"
            )

        for result in too_short:

            if not result["empty"]:

                print(
                    f"Chapter "
                    f"{result['number']}: "
                    f"{result['characters']:,} "
                    f"characters"
                )

    # --------------------------------------------------------
    # UNICODE
    # --------------------------------------------------------

    if corrupted:

        print()
        print("=" * 75)
        print("POSSIBLE UNICODE / ENCODING ISSUES")
        print("=" * 75)

        for result in corrupted:

            print(
                f"Chapter {result['number']}: "
                f"{', '.join(result['corruption'])}"
            )

    # --------------------------------------------------------
    # UNEXPECTED
    # --------------------------------------------------------

    if unexpected:

        print()
        print("=" * 75)
        print("UNEXPECTED CHAPTER FILES")
        print("=" * 75)

        for number in unexpected:

            print(
                f"Chapter {number}"
            )

    # --------------------------------------------------------
    # FINAL DECISION
    # --------------------------------------------------------

    ready = (
        len(missing) == 0
        and len(empty) == 0
        and len(too_short) == 0
        and len(read_errors) == 0
    )

    print()
    print("=" * 75)

    if ready:

        print("STATUS: READY FOR FINAL BOOK BUILD")

    else:

        print("STATUS: NOT READY FOR FINAL BOOK BUILD")

    print("=" * 75)

    print()

    if missing:

        print(
            "Generate the missing chapters first."
        )

    if corrupted:

        print(
            "Unicode issues were detected. "
            "Review/fix them before final DOCX."
        )

    if ready:

        print(
            "All expected chapters are present "
            "and contain sufficient content."
        )

    print()
    print(
        "No AI/API requests were made by this checker."
    )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    try:

        run_checker()

    except KeyboardInterrupt:

        print()
        print("Checker stopped by user.")

    except Exception as error:

        print()
        print("=" * 75)
        print("CHECKER ERROR")
        print("=" * 75)
        print(error)
        print("=" * 75)