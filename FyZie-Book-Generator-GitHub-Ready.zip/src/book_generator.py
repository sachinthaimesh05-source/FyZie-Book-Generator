import os
import requests
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# FYZIE GEMINI-ONLY BOOK GENERATOR
# ============================================================

API_KEY = os.getenv("GEMINI_API_KEY")

MODEL = os.getenv(
    "GEMINI_MODEL",
    "gemini-3.6-flash"
)

API_URL = (
    "https://generativelanguage.googleapis.com/"
    f"v1beta/models/{MODEL}:generateContent"
)


# ============================================================
# GEMINI QUOTA ERROR
# ============================================================

class GeminiQuotaExceeded(Exception):
    """Raised when Gemini quota/rate limit is exhausted."""

    pass


# ============================================================
# GENERATE CHAPTER
# ============================================================

def generate_chapter(prompt):

    if not API_KEY:

        raise RuntimeError(
            "GEMINI_API_KEY not found in .env"
        )

    print()
    print(
        f"  → Gemini model: {MODEL}"
    )

    headers = {

        "Content-Type":
            "application/json",

        "x-goog-api-key":
            API_KEY

    }

    data = {

        "contents": [

            {

                "parts": [

                    {

                        "text":
                            prompt

                    }

                ]

            }

        ]

    }

    response = requests.post(

        API_URL,

        headers=headers,

        json=data,

        timeout=600

    )

    # ========================================================
    # QUOTA / RATE LIMIT
    # ========================================================

    if response.status_code == 429:

        raise GeminiQuotaExceeded(
            response.text
        )

    # ========================================================
    # OTHER API ERRORS
    # ========================================================

    if not response.ok:

        raise RuntimeError(

            f"Gemini API Error "
            f"{response.status_code}: "
            f"{response.text}"

        )

    # ========================================================
    # PARSE RESPONSE
    # ========================================================

    result = response.json()

    try:

        content = (

            result["candidates"][0]
            ["content"]["parts"][0]
            ["text"]

        )

    except (
        KeyError,
        IndexError,
        TypeError
    ):

        raise RuntimeError(

            "Unexpected Gemini response:\n"
            + str(result)

        )

    if not content:

        raise RuntimeError(
            "Gemini returned empty content."
        )

    return content.strip()