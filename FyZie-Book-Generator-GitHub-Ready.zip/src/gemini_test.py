import os
import requests
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    print("ERROR: GEMINI_API_KEY not found in .env")
    raise SystemExit

url = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
"gemini-3.6-flash:generateContent"
)

headers = {
    "Content-Type": "application/json",
    "x-goog-api-key": api_key
}

data = {
    "contents": [
        {
            "parts": [
                {
                    "text": "Say hello to FyZie in one short sentence."
                }
            ]
        }
    ]
}

response = requests.post(url, headers=headers, json=data, timeout=120)

print("HTTP Status:", response.status_code)

if response.ok:
    result = response.json()
    text = result["candidates"][0]["content"]["parts"][0]["text"]
    print("\nGemini says:")
    print(text)
else:
    print("\nGemini API Error:")
    print(response.text)
