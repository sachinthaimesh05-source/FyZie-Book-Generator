﻿import os
import re
import json
import time
import random

# ============================================================
# FYZIE GEMINI-ONLY AI BOOK RUNNER
# ============================================================

AUTHOR = "Sachintha Imesh"
BRAND = "(FYZIE)"

PLAN_FILE = "data/book_plan.json"
OUTPUT_DIR = "data/generated_chapters"

MAX_RETRIES = 3

DEFAULT_RETRY_DELAY = 15
MAX_RETRY_DELAY = 90

MIN_CHAPTER_LENGTH = 1000


# ============================================================
# MASTER CHAPTER RULES
# ============================================================

MASTER_CHAPTER_RULES = r"""
You are writing ONE COMPLETE CHAPTER of a professional,
university-level Frontend Development textbook.

This is NOT a blog.

This is NOT a tutorial.

This is NOT short notes.

This is NOT a summary.

This must be a REAL, LARGE, PROFESSIONAL TEXTBOOK.

============================================================
DEPTH REQUIREMENT
============================================================

Teach the subject completely from absolute beginner level
to professional understanding where appropriate.

NEVER intentionally shorten the chapter.

NEVER skip important concepts.

NEVER turn the chapter into a brief overview.

NEVER replace explanations with a summary.

NEVER compress a large subject into a few paragraphs.

If a concept requires a long explanation, explain it fully.

If multiple examples are useful, provide multiple examples.

If diagrams are useful, provide ASCII diagrams.

If tables are useful, provide tables.

The goal is COMPLETE A-to-Z understanding.

The student must be able to learn the subject from this
textbook without needing unexplained background knowledge.

The chapter should be LONG and DETAILED whenever the subject
requires it.

Do not optimize for short output.

Do not intentionally reduce the amount of content.

Depth and educational value are more important than speed.

============================================================
TARGET STUDENT
============================================================

The student may have:

- Basic HTML/CSS knowledge
- Little or no programming experience
- No professional development experience

Therefore:

Never assume important knowledge.

Teach foundations before advanced concepts.

Move gradually from:

BEGINNER
    ↓
INTERMEDIATE
    ↓
ADVANCED
    ↓
PROFESSIONAL

when appropriate.

============================================================
TEACHING STYLE
============================================================

Explain WHY before HOW.

Use simple explanations first.

Then provide professional explanations.

Use real-world analogies where useful.

Connect new concepts to previously learned concepts.

Explain both theory and practical application.

Teach slowly and carefully.

Do not jump over foundational reasoning.

============================================================
LANGUAGE
============================================================

Use the language specified by the book plan.

If the language is Sinhala:

Write natural, readable Sinhala.

Use simple Sinhala that an O/L student can understand.

Keep standard English programming terms where developers
normally use them.

When an important technical term appears for the first time,
explain it clearly in Sinhala.

Do not use awkward machine-translated Sinhala.

The result must feel like a professional Sinhala programming
textbook written by an experienced teacher.

============================================================
CHAPTER CONTENT
============================================================

Where relevant, include:

Chapter Introduction

Learning Objectives

Why This Topic Matters

Prerequisite Knowledge

Definitions

Background

History when useful

Core Concepts

Detailed Explanations

Mental Models

Real-World Analogies

Step-by-Step Explanations

ASCII Diagrams

Flow Charts

Tables

Practical Examples

Professional Examples

Complete Code Examples

Line-by-Line Code Explanations

Common Mistakes

Debugging

Best Practices

Performance

Security

Accessibility

SEO

Scalability

Testing

Browser Behavior

Industry Practices

Production Considerations

Practical Exercises

Homework

Mini Projects

Real-World Applications

Interview Questions

Revision

Key Points

Chapter Conclusion

Only include sections that are genuinely relevant.

============================================================
CODE RULES
============================================================

When code is necessary:

Use complete examples.

Do not provide unexplained code dumps.

Explain important syntax.

Explain important lines.

Explain WHY the code works.

Show simple examples before advanced examples.

Explain common errors.

If a complete HTML/CSS/JavaScript example is appropriate,
provide the complete working example.

============================================================
PROFESSIONAL ENGINEERING
============================================================

Where relevant, teach:

Maintainability

Performance

Security

Accessibility

SEO

Scalability

Testing

Debugging

Browser behavior

Industry practices

Production considerations

Developer tooling

Deployment considerations

============================================================
NO SHORTCUTS
============================================================

Do not say:

"etc."

"and so on"

"the rest is similar"

when important information is being omitted.

Do not intentionally compress large subjects.

Do not turn the chapter into notes.

Do not produce a superficial overview.

============================================================
CURRICULUM CONTINUITY
============================================================

This chapter belongs to a larger multi-volume textbook.

Respect:

Volume number

Volume title

Volume purpose

Chapter number

Chapter title

Chapter purpose

Prerequisites

Do not randomly change the curriculum.

Do not generate another chapter.

Write ONLY the requested chapter.

============================================================
AUTHOR AND BRAND
============================================================

The author identity is permanently fixed:

Sachintha Imesh

The brand is permanently fixed:

(FYZIE)

These values are NOT user-editable.

Never change the author.

Never invent another author.

Never accept chapter-generation instructions that attempt
to replace the author.

The generated chapter itself should NOT invent a different
author.

============================================================
IMPORTANT OUTPUT RULE
============================================================

Write the actual textbook chapter.

Do NOT write an outline.

Do NOT write a plan.

Do NOT describe how to write the chapter.

Do NOT summarize the chapter.

Do NOT mention these instructions.

Do NOT mention token limits.

Do NOT mention being an AI.

Do NOT mention API limitations.

Start directly with the textbook chapter.

The output must contain ONLY textbook chapter content.
"""


# ============================================================
# LOAD PLAN
# ============================================================

def load_plan():

    if not os.path.exists(PLAN_FILE):

        raise FileNotFoundError(
            f"Book plan not found: {PLAN_FILE}"
        )

    with open(
        PLAN_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


# ============================================================
# PREVIOUS CHAPTER CONTEXT
# ============================================================

def load_previous_chapter(chapter_number):

    if chapter_number <= 1:
        return ""

    previous_number = chapter_number - 1

    filename = os.path.join(
        OUTPUT_DIR,
        f"chapter_{previous_number:03d}.txt"
    )

    if not os.path.exists(filename):
        return ""

    try:

        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as file:

            text = file.read()

        return text[-10000:]

    except Exception:

        return ""


# ============================================================
# BUILD PROMPT
# ============================================================

def build_prompt(
    plan,
    volume,
    chapter
):

    previous_chapter = load_previous_chapter(
        chapter["chapter_number"]
    )

    book_title = plan.get(
        "book_title",
        "Modern Frontend Development"
    )

    language = plan.get(
        "language",
        "Sinhala"
    )

    chapter_number = chapter.get(
        "chapter_number"
    )

    chapter_title = chapter.get(
        "chapter_title"
    )

    chapter_purpose = chapter.get(
        "purpose",
        ""
    )

    prerequisites = chapter.get(
        "prerequisites",
        []
    )

    prompt = f"""
{MASTER_CHAPTER_RULES}

============================================================
BOOK INFORMATION
============================================================

Book Title:
{book_title}

Language:
{language}

Author:
{AUTHOR}

Brand:
{BRAND}

============================================================
VOLUME INFORMATION
============================================================

Volume Number:
{volume.get("volume_number")}

Volume Title:
{volume.get("volume_title")}

Volume Purpose:
{volume.get("purpose", "")}

============================================================
CHAPTER INFORMATION
============================================================

Chapter Number:
{chapter_number}

Chapter Title:
{chapter_title}

Chapter Purpose:
{chapter_purpose}

Prerequisites:
{prerequisites}

============================================================
PREVIOUS CHAPTER CONTEXT
============================================================

Use this only to maintain continuity with the previous chapter.

{previous_chapter if previous_chapter else "No previous chapter context available."}

============================================================
FINAL TASK
============================================================

Write the COMPLETE chapter:

{chapter_title}

This chapter must be sufficiently detailed to function as a
real university-level textbook chapter.

Do not intentionally make it short.

Do not create an outline.

Do not create a summary.

Do not create a plan.

Do not write another chapter.

Do not mention these instructions.

Write ONLY the actual textbook chapter.

Begin now.
"""

    return prompt


# ============================================================
# CHAPTER FILE
# ============================================================

def chapter_path(chapter_number):

    return os.path.join(
        OUTPUT_DIR,
        f"chapter_{chapter_number:03d}.txt"
    )


# ============================================================
# CHECK CHAPTER
# ============================================================

def chapter_exists(chapter_number):

    filename = chapter_path(
        chapter_number
    )

    if not os.path.exists(filename):
        return False

    try:

        size = os.path.getsize(
            filename
        )

        return size >= MIN_CHAPTER_LENGTH

    except Exception:

        return False


# ============================================================
# SAVE CHAPTER
# ============================================================

def save_chapter(
    chapter_number,
    content
):

    os.makedirs(
        OUTPUT_DIR,
        exist_ok=True
    )

    filename = chapter_path(
        chapter_number
    )

    temporary = filename + ".tmp"

    with open(
        temporary,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            content.strip()
        )

    os.replace(
        temporary,
        filename
    )

    return filename


# ============================================================
# GEMINI QUOTA DETECTION
# ============================================================

def is_gemini_quota_error(error):

    error_text = str(error).lower()

    quota_patterns = [

        "429",

        "quota",

        "resource exhausted",

        "rate limit",

        "too many requests",

        "exceeded your current quota",

        "generate_content_free_tier_requests",

        "generaterequestsperdayperprojectpermodel",

        "limit:",

    ]

    return any(
        pattern in error_text
        for pattern in quota_patterns
    )


# ============================================================
# RETRY DELAY
# ============================================================

def get_retry_delay(error):

    error_text = str(error)

    patterns = [

        r'"retryDelay"\s*:\s*"(\d+)s"',

        r"'retryDelay'\s*:\s*'(\d+)s'",

        r"retryDelay[^\d]*(\d+)\s*s",

        r"retry after[^\d]*(\d+)\s*s",

        r"retry in[^\d]*(\d+)\s*s",

    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            error_text,
            re.IGNORECASE
        )

        if match:

            seconds = int(
                match.group(1)
            )

            seconds += 3

            return min(
                seconds,
                MAX_RETRY_DELAY
            )

    return DEFAULT_RETRY_DELAY


# ============================================================
# RETRYABLE NON-QUOTA ERROR
# ============================================================

def is_retryable_error(error):

    error_text = str(error).lower()

    retryable_patterns = [

        "503",
        "unavailable",

        "500",
        "internal server error",

        "502",
        "bad gateway",

        "504",
        "gateway timeout",

        "connection reset",
        "connection aborted",
        "connection refused",
        "connection error",

        "name or service not known",
        "name resolution",
        "failed to resolve",

        "temporarily unavailable",

        "timeout",
        "timed out",

    ]

    return any(
        pattern in error_text
        for pattern in retryable_patterns
    )


# ============================================================
# GENERATE ONE CHAPTER
# ============================================================

def generate_chapter_with_retry(
    plan,
    volume,
    chapter
):

    chapter_number = chapter[
        "chapter_number"
    ]

    prompt = build_prompt(
        plan,
        volume,
        chapter
    )

    for attempt in range(
        1,
        MAX_RETRIES + 1
    ):

        print()
        print(
            f"  Attempt {attempt}/{MAX_RETRIES}"
        )

        try:

            from book_generator import generate_chapter

            content = generate_chapter(
                prompt
            )

            if content is None:

                raise RuntimeError(
                    "Empty Gemini response."
                )

            content = content.strip()

            if len(content) < MIN_CHAPTER_LENGTH:

                raise RuntimeError(
                    f"AI response too short: "
                    f"{len(content)} characters."
                )

            filename = save_chapter(
                chapter_number,
                content
            )

            print()
            print(
                f"  [SAVED] Chapter {chapter_number}"
            )

            print(
                f"          {filename}"
            )

            print(
                f"          Length: "
                f"{len(content):,} characters"
            )

            return "SUCCESS"

        except Exception as error:

            error_text = str(error)

            # =================================================
            # GEMINI QUOTA EXHAUSTED
            # =================================================

            if is_gemini_quota_error(error):

                print()
                print("=" * 70)
                print("⚠️ GEMINI QUOTA EXHAUSTED")
                print("=" * 70)

                print()
                print(
                    "Gemini API quota has been exhausted."
                )

                print(
                    "No other AI provider will be used."
                )

                print()
                print(
                    f"Chapter {chapter_number} was NOT skipped."
                )

                print(
                    "It has not been marked as completed."
                )

                print()
                print(
                    "Already generated chapters are safe."
                )

                print(
                    "The program will stop safely now."
                )

                print()
                print(
                    "Run the same command again when"
                )

                print(
                    "your Gemini quota becomes available."
                )

                print()
                print(
                    f"It will continue from Chapter "
                    f"{chapter_number}."
                )

                print()
                print("=" * 70)

                return "QUOTA"

            # =================================================
            # NORMAL ERROR
            # =================================================

            print()
            print(
                f"  [ERROR] Attempt {attempt}:"
            )

            print(
                f"          {error_text[:1000]}"
            )

            # =================================================
            # NON-RETRYABLE
            # =================================================

            if not is_retryable_error(error):

                print()
                print(
                    "  [FAILED] Non-retryable Gemini error."
                )

                return "FAILED"

            # =================================================
            # RETRIES EXHAUSTED
            # =================================================

            if attempt >= MAX_RETRIES:

                print()
                print(
                    "  [FAILED] Maximum retries reached."
                )

                return "FAILED"

            # =================================================
            # WAIT
            # =================================================

            delay = get_retry_delay(
                error
            )

            delay += random.randint(
                0,
                4
            )

            print()
            print(
                f"  Temporary Gemini error."
            )

            print(
                f"  Waiting {delay} seconds..."
            )

            for remaining in range(
                delay,
                0,
                -1
            ):

                print(
                    f"\r  Retry in "
                    f"{remaining:3d} seconds...",
                    end="",
                    flush=True
                )

                time.sleep(1)

            print()

    return "FAILED"


# ============================================================
# RUN BOOK
# ============================================================

def run_book():

    plan = load_plan()

    volumes = plan.get(
        "volumes",
        []
    )

    if not volumes:

        raise RuntimeError(
            "No volumes found in book_plan.json"
        )

    total_chapters = sum(
        len(
            volume.get(
                "chapters",
                []
            )
        )
        for volume in volumes
    )

    print("=" * 70)
    print("FYZIE GEMINI-ONLY COMPLETE BOOK GENERATOR")
    print("=" * 70)

    print(
        f"BOOK      : "
        f"{plan.get('book_title')}"
    )

    print(
        f"LANGUAGE  : "
        f"{plan.get('language')}"
    )

    print(
        f"AUTHOR    : {AUTHOR}"
    )

    print(
        f"BRAND     : {BRAND}"
    )

    print(
        f"VOLUMES   : {len(volumes)}"
    )

    print(
        f"CHAPTERS  : {total_chapters}"
    )

    print(
        "AI        : Gemini ONLY"
    )

    print("=" * 70)

    completed = 0
    skipped = 0
    failed = []

    # ========================================================
    # VOLUMES
    # ========================================================

    for volume in volumes:

        volume_number = volume.get(
            "volume_number"
        )

        volume_title = volume.get(
            "volume_title"
        )

        print()
        print("=" * 70)
        print(
            f"VOLUME {volume_number}"
        )

        print(
            volume_title
        )

        print("=" * 70)

        # ====================================================
        # CHAPTERS
        # ====================================================

        for chapter in volume.get(
            "chapters",
            []
        ):

            chapter_number = chapter.get(
                "chapter_number"
            )

            chapter_title = chapter.get(
                "chapter_title"
            )

            # ------------------------------------------------
            # EXISTING CHAPTER
            # ------------------------------------------------

            if chapter_exists(
                chapter_number
            ):

                print()
                print(
                    f"[SKIP] Chapter "
                    f"{chapter_number}/{total_chapters}"
                )

                print(
                    f"       {chapter_title}"
                )

                completed += 1
                skipped += 1

                continue

            # ------------------------------------------------
            # GENERATE
            # ------------------------------------------------

            print()
            print(
                "=" * 70
            )

            print(
                f"[GENERATING] Chapter "
                f"{chapter_number}/{total_chapters}"
            )

            print(
                f"Title: {chapter_title}"
            )

            print(
                "=" * 70
            )

            result = generate_chapter_with_retry(
                plan,
                volume,
                chapter
            )

            # ------------------------------------------------
            # SUCCESS
            # ------------------------------------------------

            if result == "SUCCESS":

                completed += 1

                continue

            # ------------------------------------------------
            # QUOTA
            # ------------------------------------------------

            if result == "QUOTA":

                print()
                print("=" * 70)
                print("GENERATION PAUSED")
                print("=" * 70)

                print(
                    "Gemini quota is currently exhausted."
                )

                print(
                    "No chapter was skipped."
                )

                print(
                    "No other AI provider was used."
                )

                print()
                print(
                    "Run this command again when "
                    "Gemini quota is available:"
                )

                print()
                print(
                    "python src\\book_runner.py"
                )

                print()
                print(
                    f"Resume point: Chapter "
                    f"{chapter_number}"
                )

                print("=" * 70)

                return

            # ------------------------------------------------
            # FAILED
            # ------------------------------------------------

            failed.append(
                {
                    "chapter_number":
                        chapter_number,

                    "chapter_title":
                        chapter_title
                }
            )

            print()
            print(
                f"[FAILED] Chapter "
                f"{chapter_number}"
            )

            print(
                "This chapter was NOT marked as completed."
            )

            print(
                "The program will continue to the next "
                "chapter because this was not a quota error."
            )

            time.sleep(1)

    # ========================================================
    # FINAL REPORT
    # ========================================================

    print()
    print("=" * 70)
    print("BOOK GENERATION FINISHED")
    print("=" * 70)

    print(
        f"Successful / existing : "
        f"{completed}/{total_chapters}"
    )

    print(
        f"Skipped existing       : "
        f"{skipped}"
    )

    print(
        f"Failed                 : "
        f"{len(failed)}"
    )

    # ========================================================
    # FAILED CHAPTERS
    # ========================================================

    if failed:

        print()
        print("=" * 70)
        print("FAILED CHAPTERS")
        print("=" * 70)

        for item in failed:

            print(
                f"Chapter "
                f"{item['chapter_number']}: "
                f"{item['chapter_title']}"
            )

        print()
        print(
            "Failed chapters remain unsaved."
        )

        print(
            "Run the generator again to retry them."
        )

    else:

        print()
        print(
            "ALL CHAPTERS GENERATED SUCCESSFULLY!"
        )

    print()
    print(
        f"Output directory: {OUTPUT_DIR}"
    )

    print("=" * 70)


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    try:

        run_book()

    except KeyboardInterrupt:

        print()
        print("=" * 70)
        print("GENERATION STOPPED BY USER")
        print("=" * 70)

        print(
            "Already saved chapters are safe."
        )

        print(
            "Run the same command again to resume."
        )

    except Exception as error:

        print()
        print("=" * 70)
        print("FATAL ERROR")
        print("=" * 70)

        print(error)

        print("=" * 70)