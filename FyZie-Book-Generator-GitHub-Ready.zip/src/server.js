require("dotenv").config();

const { GoogleGenAI } = require("@google/genai");

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

async function testAI() {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "Say hello to FyZie in one short sentence.",
    });

    console.log(response.text);
  } catch (error) {
    console.error("AI ERROR:", error.message);
  }
}

testAI();