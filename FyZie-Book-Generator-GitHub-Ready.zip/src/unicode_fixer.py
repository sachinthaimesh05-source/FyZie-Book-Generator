import os
import shutil

# ============================================================
# FYZIE UNIVERSAL UNICODE / MOJIBAKE FIXER
# ============================================================

CHAPTER_DIR = "data/generated_chapters"

# Only chapters containing these patterns will be processed.
CORRUPTED_PATTERNS = [
    "Ã",
    "Â",
    "â€",
    "â„",
    "â†",
    "âœ",
    "â”",
    "â–",
    "ðŸ",
]


# ============================================================
# MOJIBAKE REPAIR
# ============================================================

def repair_mojibake(text):
    """
    Repairs common UTF-8 -> Windows-1252/Latin-1 mojibake.

    Example:
        â€¢  -> •
        â€“  -> –
        â€”  -> —
        Ã©  -> é
        Ã  -> possible mojibake sequence
    """

    current = text

    # Usually one pass is enough.
    # A second pass handles text that was corrupted more than once.
    for _ in range(2):

        try:
            repaired = current.encode(
                "latin1"
            ).decode(
                "utf-8"
            )

        except (UnicodeEncodeError, UnicodeDecodeError):

            break

        if repaired == current:
            break

        current = repaired

    return current


# ============================================================
# CHECK IF TEXT STILL LOOKS CORRUPTED
# ============================================================

def find_corruption(text):

    found = []

    for pattern in CORRUPTED_PATTERNS:

        if pattern in text:

            found.append(pattern)

    return found


# ============================================================
# FIX ONE FILE
# ============================================================

def fix_file(path):

    print()
    print("-" * 70)
    print(f"Checking: {path}")

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as file:

            original = file.read()

    except Exception as error:

        print(f"[READ ERROR] {error}")
        return False

    before = find_corruption(original)

    if not before:

        print("[OK] No obvious Unicode corruption found.")
        return False

    print(
        "[FOUND] "
        + ", ".join(before)
    )

    # --------------------------------------------------------
    # CREATE BACKUP
    # --------------------------------------------------------

    backup_path = path + ".backup"

    if not os.path.exists(backup_path):

        shutil.copy2(
            path,
            backup_path
        )

        print(
            f"[BACKUP CREATED] {backup_path}"
        )

    else:

        print(
            "[BACKUP EXISTS] Original backup preserved."
        )

    # --------------------------------------------------------
    # REPAIR
    # --------------------------------------------------------

    repaired = repair_mojibake(
        original
    )

    after = find_corruption(
        repaired
    )

    # --------------------------------------------------------
    # SAVE
    # --------------------------------------------------------

    if repaired != original:

        with open(
            path,
            "w",
            encoding="utf-8",
            newline=""
        ) as file:

            file.write(
                repaired
            )

        print("[CHANGED] Unicode corruption repaired.")

    else:

        print(
            "[NO AUTOMATIC CHANGE] "
            "Encoding conversion did not produce a safe change."
        )

    # --------------------------------------------------------
    # FINAL CHECK
    # --------------------------------------------------------

    if after:

        print(
            "[WARNING] Possible corruption remains:"
        )

        print(
            "          "
            + ", ".join(after)
        )

        return False

    print(
        "[SUCCESS] No known mojibake patterns remain."
    )

    return True


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("FYZIE UNIVERSAL UNICODE FIXER")
    print("=" * 70)
    print("Mode: LOCAL FILE ONLY")
    print("AI/API calls: NONE")
    print("=" * 70)

    if not os.path.exists(CHAPTER_DIR):

        print()
        print(
            f"[ERROR] Directory not found: {CHAPTER_DIR}"
        )

        return

    # --------------------------------------------------------
    # Find chapter files
    # --------------------------------------------------------

    chapter_files = []

    for filename in os.listdir(CHAPTER_DIR):

        if filename.lower().endswith(".txt"):

            if filename.lower().startswith(
                "chapter_"
            ):

                chapter_files.append(
                    filename
                )

    chapter_files.sort()

    if not chapter_files:

        print()
        print("[ERROR] No chapter files found.")
        return

    print()
    print(
        f"Chapter files found: {len(chapter_files)}"
    )

    changed = 0
    clean = 0
    failed = 0

    # --------------------------------------------------------
    # Process files
    # --------------------------------------------------------

    for filename in chapter_files:

        path = os.path.join(
            CHAPTER_DIR,
            filename
        )

        result = fix_file(
            path
        )

        if result:

            changed += 1

        else:

            # Check again to distinguish clean
            # from failed repair.

            try:

                with open(
                    path,
                    "r",
                    encoding="utf-8"
                ) as file:

                    content = file.read()

                remaining = find_corruption(
                    content
                )

                if remaining:

                    failed += 1

                else:

                    clean += 1

            except Exception:

                failed += 1

    # --------------------------------------------------------
    # SUMMARY
    # --------------------------------------------------------

    print()
    print("=" * 70)
    print("UNICODE FIX SUMMARY")
    print("=" * 70)

    print(
        f"Files processed : {len(chapter_files)}"
    )

    print(
        f"Files changed   : {changed}"
    )

    print(
        f"Already clean   : {clean}"
    )

    print(
        f"Still problematic: {failed}"
    )

    print("=" * 70)

    if failed == 0:

        print(
            "UNICODE CHECK COMPLETE"
        )

    else:

        print(
            "WARNING: Some files may still contain "
            "encoding corruption."
        )

    print("=" * 70)


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    try:

        main()

    except KeyboardInterrupt:

        print()
        print("Stopped by user.")

    except Exception as error:

        print()
        print("=" * 70)
        print("FIXER ERROR")
        print("=" * 70)
        print(error)
        print("=" * 70)